# StudySpace

A lightweight notes and study planner web app.

## Publish with GitHub Pages

1. Create a new GitHub repository (or use an existing one).
2. Upload `index.html` to the repository's root folder.
3. Open the repository's **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Choose branch `main` and folder `/ (root)`, then Save.
6. Wait for GitHub Pages to publish the site. The URL will be shown in the Pages settings.

The app stores notes and tasks in the browser's local storage. Use Export my data to make backups.
